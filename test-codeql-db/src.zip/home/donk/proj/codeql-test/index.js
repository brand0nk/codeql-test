console.log("hello world!");

// do some math
// comment with KEYWORDS
let i = 0;
let x = 15;
i = x + i;
i = Math.pow(i, 3);

console.log(i, x);